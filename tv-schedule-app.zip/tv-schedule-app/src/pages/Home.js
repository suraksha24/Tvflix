import React from "react";
import ShowList from "../components/ShowList";

const Home = () => {
  return (
    <div className="main-content"> 
      <h2 style={{ marginLeft: "1%" }}>Currently Airing TV Shows</h2>
      <ShowList />
    </div>
  );
};

export default Home;

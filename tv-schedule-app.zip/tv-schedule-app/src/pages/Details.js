import React from "react";
import ShowDetails from "../components/ShowDetails";

const Details = () => {
  return (
    <div className="main-content">
      <ShowDetails />
    </div>
  );
};

export default Details;

import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { getShowDetails } from "../api/tvmazeApi";
import LoadingSpinner from "./LoadingSpinner";
import ArrowBackIcon from '@mui/icons-material/ArrowBack'; 

const ShowDetails = () => {
  const { id } = useParams();
  const [show, setShow] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    getShowDetails(id).then(setShow);
  }, [id]);

  if (!show) return <LoadingSpinner />;


  const handleBackClick = () => {
    navigate(-1); 
  };

  return (
    <div className="show-details">
      <div onClick={handleBackClick} className="back-icon">
        <ArrowBackIcon style={{ fontSize: 30, color: 'white', cursor: 'pointer' }} /> 
      </div>

      <img
        src={show.image?.original || "https://via.placeholder.com/300"}
        alt={show.name}
      />
      <h2>{show.name}</h2>
      <p dangerouslySetInnerHTML={{ __html: show.summary }} />
      <p><strong>Genres:</strong> {show.genres.join(", ")}</p>
      <p><strong>Language:</strong> {show.language}</p>
      <p><strong>Premiered:</strong> {show.premiered}</p>
      <p><strong>Rating:</strong> {show.rating?.average || "N/A"}</p>
    </div>
  );
};

export default ShowDetails;

import React from "react";
import { Link } from "react-router-dom";

const ShowCard = ({ show }) => {
  return (
    <div className="show-card">
      <Link to={`/details/${show.id}`}>
        <img src={show.image?.medium || "https://via.placeholder.com/210"} alt={show.name} />
      </Link>
    </div>
  );
};

export default ShowCard;

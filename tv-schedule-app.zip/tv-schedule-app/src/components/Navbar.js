import React from "react";
import { Link } from "react-router-dom";
import { Movie } from "@mui/icons-material"; 

const Navbar = () => {
  return (
    <nav className="navbar">
      <Movie style={{ color: "red", fontSize: "28px", marginRight: "10px" }} />
      <h1>TVflix</h1>
      <Link to="/">Home</Link>
    </nav>
  );
};

export default Navbar;

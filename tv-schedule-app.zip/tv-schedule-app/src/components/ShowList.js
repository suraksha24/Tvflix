import React, { useEffect, useState } from "react";
import { getUSSchedule } from "../api/tvmazeApi";
import ShowCard from "./ShowCard";
import LoadingSpinner from "./LoadingSpinner"; 

const ShowList = () => {
  const [shows, setShows] = useState({});
  const [isLoading, setIsLoading] = useState(true); 

  useEffect(() => {
    getUSSchedule().then((data) => {
      const categorizedShows = {};

      data.forEach(({ show }) => {
        const genre = show.genres.length > 0 ? show.genres[0] : "Other"; 
        if (!categorizedShows[genre]) {
          categorizedShows[genre] = [];
        }
        categorizedShows[genre].push(show);
      });

      setShows(categorizedShows);
      setIsLoading(false); 
    });
  }, []);

  if (isLoading) return <LoadingSpinner />; 

  return (
    <div className="show-categories">
      {Object.entries(shows).map(([genre, showList]) => (
        <div key={genre} className="category-section">
          <h2 className="category-title">{genre}</h2>
          <div className="show-list">
            {showList.map((show) => (
              <ShowCard key={show.id} show={show} />
            ))}
          </div>
        </div>
      ))}
    </div>
  );
};

export default ShowList;
